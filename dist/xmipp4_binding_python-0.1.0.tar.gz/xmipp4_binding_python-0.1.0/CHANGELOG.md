# Release v0.1.0
Initial xmipp4-binding-python release. Still work in progress.

- Implemented a Python binding of the most useful C++ functions and classes.
